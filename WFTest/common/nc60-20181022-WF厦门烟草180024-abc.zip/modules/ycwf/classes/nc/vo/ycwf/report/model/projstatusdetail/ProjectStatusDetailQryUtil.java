package nc.vo.ycwf.report.model.projstatusdetail;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import nc.bs.logging.Logger;
import nc.jdbc.framework.processor.BaseProcessor;
import nc.vo.pub.BusinessException;
import nc.vo.yc.utils.QueryUtil;
import nc.vo.yc.utils.hash.HashVO;

/**
 * ��Ŀ״̬��ϸ��--����Ŀ  ִ��sql���
 * @author yanghc
 * @date  2017-06-02
 */
public class ProjectStatusDetailQryUtil {
	
	 /**
     * ��ȡ��Ŀ���͡���ͬ�š���ͬǩ�����ڵ�ԭʼ����
     * @param
     * @return
     */
	@SuppressWarnings("serial")
	public List<HashVO> getProjecttypeQry(Map<String,String> queryMap,String[] pkProjectapprove) {
		StringBuffer sql = new StringBuffer();
		sql.append("select a.vcode,c.pk_product as pk_product,c.pk_projecttype as contract_projecttype,e.pk_projecttype as projectapprove_projecttype,");
		sql.append(" d.vcode as contract_vcode,d.nprocessrate as nprocessrate,d.isreceivemnyfinish as isreceivemnyfinish,max(c.ntotalrecetaxmny) as contract_ntotalrecetaxmny,");
		sql.append(" max(d.ndealmny) as contract_dealmny,d.ddealdate,max(c.ncontractmny) as contract_mny,max(e.nplansigenedmny) as projectapprove_mny");
		sql.append(" from ycwf_projectapprove a left join ycwf_contract_b c on c.vlastbillid=a.pk_projectapprove");
		sql.append(" left join ycwf_contract d on c.pk_contract=d.pk_contract");
		sql.append(" inner join ycwf_projectapprove_b e on a.pk_projectapprove=e.pk_projectapprove");
		StringBuffer otherWhere = new StringBuffer();
		otherWhere.append(queryMap.get("pkBu")).append(" and isnull(d.vbillstatus,1)=1 and isnull(c.dr,0)=0 and isnull(d.dr,0)=0 and isnull(e.dr,0)=0");
		String groupFields = "a.vcode,c.pk_product,c.pk_projecttype,d.vcode,d.nprocessrate,d.isreceivemnyfinish,d.ddealdate,e.pk_projecttype";
		final List<HashVO> list = new ArrayList<HashVO>();
		try {
			QueryUtil.executeQueryWithIn(sql.toString(),"a.pk_projectapprove", pkProjectapprove, new BaseProcessor(){
				@Override
				public Object processResultSet(ResultSet rs) throws SQLException {
					ResultSetMetaData rsmd = rs.getMetaData();
					int nColumnCount = rsmd.getColumnCount();
					
					HashVO voTmp;
					while(rs.next())
					{
						voTmp = new HashVO();
						for (int k = 1; k <= nColumnCount; k++) {
							Object value = rs.getObject(k);
							voTmp.setAttributeValue(rsmd.getColumnName(k), value);
						}
						list.add(voTmp);
					}
					return null;
				}
				
			}, otherWhere.toString(),groupFields,null);
		} catch (BusinessException e) {
			Logger.error(e.getMessage(),e);
			throw new RuntimeException(e.getMessage(),e);
		}
		return list;
	}
	
	 /**
     * ��ȡ��Ŀ״̬����Ŀ��ǰ��̱���ԭʼ����
     * @param
     * @return
     */
	@SuppressWarnings("serial")
	public List<HashVO> getImilepostQry(Map<String,String> queryMap,String[] pkProjectapprove) {
		StringBuffer sql = new StringBuffer();
		sql.append("select a.vcode,c.iprojecthealthstatus,c.imilepost,b.isfinish,max(c.dreportenddate) as dreportenddate");
		sql.append(" from ycwf_projectapprove a left join ycwf_outstart b on a.pk_projectapprove=b.pk_projectapprove");
		sql.append(" inner join ycwf_projectweekreport c on a.pk_projectapprove=c.pk_projectapprove");
		StringBuffer otherWhere = new StringBuffer();
		otherWhere.append(queryMap.get("pkBu")).append(" and c.dreportenddate<='").append(queryMap.get("dFinishDate")).append("'").append(" and c.vbillstatus=1 and isnull(c.dr,0)=0");
		String groupFields = "a.vcode,c.iprojecthealthstatus,c.imilepost,b.isfinish";
		final List<HashVO> list = new ArrayList<HashVO>();
		try {
			QueryUtil.executeQueryWithIn(sql.toString(),"a.pk_projectapprove", pkProjectapprove, new BaseProcessor(){
				@Override
				public Object processResultSet(ResultSet rs) throws SQLException {
					ResultSetMetaData rsmd = rs.getMetaData();
					int nColumnCount = rsmd.getColumnCount();
					HashVO voTmp;
					while(rs.next())
					{
						voTmp = new HashVO();
						for (int k = 1; k <= nColumnCount; k++) {
							Object value = rs.getObject(k);
							voTmp.setAttributeValue(rsmd.getColumnName(k), value);
						}
						list.add(voTmp);
					}
					return null;
				}
				
			}, otherWhere.toString(),groupFields,null);
		} catch (BusinessException e) {
			Logger.error(e.getMessage(),e);
			throw new RuntimeException(e.getMessage(),e);
		}
		return list;
	}
	
	 /**
     * ��ȡʵ�������ԭʼ����
     * @param
     * @return
     */
	@SuppressWarnings("serial")
	public List<HashVO> getNumQry(Map<String,String> queryMap,String[] pkProjectapprove) {
		StringBuffer sql = new StringBuffer();
		sql.append("select a.vcode,sum(d.nstandardnum)+sum(d.novertimenum) as rprojectsumnum,sum(d.nsupportnum)+sum(d.nsupportovernum) as rsupportnum,sum(d.nnum) as nnum,sum(d.ncostmny) as ncostmny");
		sql.append(" from ycwf_projectapprove a inner join ycwf_projectweekreport c on a.pk_projectapprove=c.pk_projectapprove");
		sql.append(" left join ycwf_week_workcount d on c.pk_projectweekreport=d.pk_projectweekreport");
		StringBuffer otherWhere = new StringBuffer();
		otherWhere.append(queryMap.get("pkBu")).append(" and c.vbillstatus=1 and c.dreportenddate<='").append(queryMap.get("dFinishDate")).append("'").append(" and isnull(c.dr,0)=0 and isnull(d.dr,0)=0");
		String groupFields = "a.vcode";
		final List<HashVO> list = new ArrayList<HashVO>();
		try {
			QueryUtil.executeQueryWithIn(sql.toString(),"a.pk_projectapprove", pkProjectapprove, new BaseProcessor(){
				@Override
				public Object processResultSet(ResultSet rs) throws SQLException {
					ResultSetMetaData rsmd = rs.getMetaData();
					int nColumnCount = rsmd.getColumnCount();
					HashVO voTmp;
					while(rs.next())
					{
						voTmp = new HashVO();
						for (int k = 1; k <= nColumnCount; k++) {
							Object value = rs.getObject(k);
							voTmp.setAttributeValue(rsmd.getColumnName(k), value);
						}
						list.add(voTmp);
					}
					return null;
				}
				
			}, otherWhere.toString(),groupFields,null);
		} catch (BusinessException e) {
			Logger.error(e.getMessage(),e);
			throw new RuntimeException(e.getMessage(),e);
		}
		return list;
	}
	
	 /**
     * ��ȡʱ���ԭʼ����
     * @param
     * @return
     */
	@SuppressWarnings("serial")
	public List<HashVO> getTimeQry(Map<String,String> queryMap,String[] pkProjectapprove) {
		StringBuffer sql = new StringBuffer();
		sql.append("select a.vcode,b.imilepostdef,c.imilepost,min(c.dplanstartdate) as dplanstartdate,min(c.drealstartdate) as drealstartdate,");
		sql.append("max(c.dplanfinishdate) as dplanfinishdate,max(c.dplanenddate) as dplanenddate,max(c.drealfinishdate) as drealfinishdate");
		sql.append(" from ycwf_projectapprove a left join ycwf_outstart b on a.pk_projectapprove=b.pk_projectapprove");
		sql.append(" inner join ycwf_outstart_milepost c on b.pk_outstart=c.pk_outstart");
		StringBuffer otherWhere = new StringBuffer();
		//1:��Ŀ�滮,4:�����л�,5:����֧��,6:����ȷ��,7:��Ŀ�ܽ�
		otherWhere.append(queryMap.get("pkBu")).append(" and c.imilepost in (1,4,5,6,7) and isnull(c.dr,0)=0");
		String groupFields = "a.vcode,b.imilepostdef,c.imilepost";
		final List<HashVO> list = new ArrayList<HashVO>();
		try {
			QueryUtil.executeQueryWithIn(sql.toString(),"a.pk_projectapprove", pkProjectapprove, new BaseProcessor(){
				@Override
				public Object processResultSet(ResultSet rs) throws SQLException {
					ResultSetMetaData rsmd = rs.getMetaData();
					int nColumnCount = rsmd.getColumnCount();
					HashVO voTmp;
					while(rs.next())
					{
						voTmp = new HashVO();
						for (int k = 1; k <= nColumnCount; k++) {
							Object value = rs.getObject(k);
							voTmp.setAttributeValue(rsmd.getColumnName(k), value);
						}
						list.add(voTmp);
					}
					return null;
				}
				
			}, otherWhere.toString(),groupFields,null);
		} catch (BusinessException e) {
			Logger.error(e.getMessage(),e);
			throw new RuntimeException(e.getMessage(),e);
		}
		return list;
	}
}
