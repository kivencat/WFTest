package nc.vo.ycwf.report.model.projstatusdetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nc.jdbc.framework.SQLParameter;
import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.pub.report.TempletModelGroupVO;
import nc.vo.trade.report.QueryContext;
import nc.vo.trade.report.ReportVOMetaClass;
import nc.vo.trade.report.ext2.FillInfoVO;
import nc.vo.trade.report.vofill.AbstractReportFactory;
import nc.vo.trade.report.vofill.IVOFill;
import nc.vo.yc.utils.YCPubUtils;
import nc.vo.ycwf.pub.YCWFUtils;
import nc.vo.ycwf.pub.report.WFAbsFillReportDataModel;

import com.aspose.retro.edu.emory.mathcs.backport.java.util.Arrays;

/**
 * ��Ŀ״̬��ϸ��--����Ŀ  DataModel��
 * @author yanghc
 * @date  2017-06-02
 */
@SuppressWarnings("serial")
public class ProjectStatusDetailDM extends WFAbsFillReportDataModel{
	
	Map<String,String> queryMap = new HashMap<String,String>();//keyΪ��ѯ������valueΪ��ѯ������ֵ
	
	public ProjectStatusDetailDM(TempletModelGroupVO templetModelGroupVO) {
		super(templetModelGroupVO);
	}

	/**
	 * ��ȡ��ѯ������
	 */
	@Override
	public QueryContext[] getQueryContext(SQLParameter params, String sqlWhere) {
		String isFinish = getSingleConditionValue(YCWFUtils.getConditionByName(sqlWhere,"b.isfinish"));
		String dFinishDate = getSingleConditionValue(YCWFUtils.getConditionByName(sqlWhere,"b.dfinishdate"));
		String isAccept = getSingleConditionValue(YCWFUtils.getConditionByName(sqlWhere,"b.isaccept"));
		String isReceipt = getSingleConditionValue(YCWFUtils.getConditionByName(sqlWhere,"b.isreceipt"));
		String imilepost = getSingleConditionValue(YCWFUtils.getConditionByName(sqlWhere,"b.imilepost"));
		queryMap.put("isFinish", isFinish);
		queryMap.put("dFinishDate", dFinishDate);
		queryMap.put("isAccept", isAccept);
		queryMap.put("isReceipt", isReceipt);
		queryMap.put("imilepost", imilepost);
		sqlWhere = YCWFUtils.removeSubConditions(sqlWhere,"b.isfinish");
		sqlWhere = YCWFUtils.removeSubConditions(sqlWhere,"b.dfinishdate");
		sqlWhere = YCWFUtils.removeSubConditions(sqlWhere,"b.isaccept");
		sqlWhere = YCWFUtils.removeSubConditions(sqlWhere,"b.isreceipt");
		sqlWhere = YCWFUtils.removeSubConditions(sqlWhere,"b.imilepost");
		queryMap.put("pkBu", sqlWhere);//a.pk_bu ��ѯģ������������Ȩ�ޣ�ʣ�µ�where���Ϊbu����
		QueryContext[] ctxs = new QueryContext[1];
		ctxs[0] = ProjectStatusDetailMetaFactory.getContractContext(params, sqlWhere, queryMap);
		return ctxs;
	}
	
	/**
	 * ��ȡwhere������ĳ���ֶε�ֵ
	 */
	private String getSingleConditionValue(String condPart){
		String retStr = null;
		String effectWhere= condPart.replaceAll("1=1", "");
		if(YCPubUtils.isEmpty(effectWhere)) return null;
		int ePos = effectWhere.indexOf("=");
		int inPos = effectWhere.indexOf(" in "); //�ӿո��ֹ����
		if(ePos  >= 0){ 
			// ����ǵ���ֵ�� ֱ�ӽ�ȡ
			retStr = effectWhere.substring(ePos+1, effectWhere.length()).trim();
		}else if(inPos >= 0){
			//����Ƕ��ֵ�� ȥ����
			int zkh = effectWhere.indexOf("(");
			int ykh = effectWhere.indexOf(")");
			if(zkh>inPos && ykh > zkh){
				retStr = effectWhere.substring(zkh+1, ykh);
			}
		}
		//ȥ�� "'" �� ����еĻ�
		retStr = retStr.trim();
		if(retStr.contains("'")){
			retStr = retStr.substring(1, retStr.length()-1);
		}
		return retStr;
	}
	
	@Override
	public FillInfoVO[] getFillInfoVO() {
		FillInfoVO[] infos = new FillInfoVO[1];
		FillInfoVO info = new FillInfoVO();
		info.setFillType(0);
		info.setFillKey(new String[]{"a.vcode"});
		infos[0] = info;
		return infos;
	}

	@Override
	public AbstractReportFactory getReportFactory(final ReportVOMetaClass voMeta) {
		return new AbstractReportFactory() {
			@Override
			public IVOFill createIVOFill(int sourceDataType) {
				switch(sourceDataType){
					case 0:
						return new ProjectStatusDetailVOFill(this);
					default :
						throw new RuntimeException("�Ƿ��Ĳ���: " + sourceDataType);
				}
			}
			@Override
			public ReportVOMetaClass createReportVOMetaClass() {
				return voMeta;
			}
		};
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public CircularlyAccessibleValueObject[] doProcess(CircularlyAccessibleValueObject[] bodyVOs) {
		new ProjectStatusDetailProcess(queryMap).doProcess(bodyVOs);
		bodyVOs = super.doProcess(bodyVOs);
		List<CircularlyAccessibleValueObject> retBodyVOs = new ArrayList<CircularlyAccessibleValueObject>();
		String isAccept = queryMap.get("isAccept");
		String isReceipt = queryMap.get("isReceipt");
		String imilepost = queryMap.get("imilepost");
		for(CircularlyAccessibleValueObject vo : bodyVOs){
			if(!YCPubUtils.isEmpty(isAccept)){
				if(!isAccept.equals(vo.getAttributeValue("isaccept"))){
					continue;
				}
			}
			if(!YCPubUtils.isEmpty(isReceipt)){
				if(!isReceipt.equals(vo.getAttributeValue("isreceivemnyfinish"))){
					continue;
				}
			}
			if(!YCPubUtils.isEmpty(imilepost)){
				List<String> imilepostArray = Arrays.asList(imilepost.replaceAll("'", "").split(","));
				if(!imilepostArray.contains(vo.getAttributeValue("imilepostname"))){
					continue;
				}
			}
			retBodyVOs.add(vo);
		}
		return retBodyVOs.toArray(new CircularlyAccessibleValueObject[0]);
	}
}
