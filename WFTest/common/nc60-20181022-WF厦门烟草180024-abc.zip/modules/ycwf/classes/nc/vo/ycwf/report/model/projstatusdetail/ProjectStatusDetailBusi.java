package nc.vo.ycwf.report.model.projstatusdetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import nc.vo.pub.lang.UFBoolean;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.lang.UFDouble;
import nc.vo.trade.voutils.SafeCompute;
import nc.vo.yc.utils.YCPubUtils;
import nc.vo.yc.utils.hash.HashVO;

/**
 * ��Ŀ״̬��ϸ��--����Ŀ  ����sql����ѯ��������
 * @author yanghc
 * @date  2017-06-02
 */
public class ProjectStatusDetailBusi {

    /**
     * ��ȡ��Ҫ����Ŀ���͡���ͬ�š���ͬǩ������
     * @param
     * @return
     */
	public Map<String,HashVO> getProjecttypeMap(Map<String,String> queryMap,String[] pkProjectapprove){
		List<HashVO> projecttypeList = new ProjectStatusDetailQryUtil().getProjecttypeQry(queryMap,pkProjectapprove);
		Set<String> codeProductSet = new HashSet<String>();//��š���Ŀpk+��Ʒpk��
		Map<String,UFDouble> codeProductMnyMap = new HashMap<String,UFDouble>();//key:��Ŀ���� value:�տ���(��˰)
		for(HashVO vo:projecttypeList){
    		String vcode = vo.getStringValue("vcode");
    		String pk_product = vo.getStringValue("pk_product");
    		//���ݡ���Ŀ�������տ���(��˰)
     		if(!codeProductSet.contains(vcode+pk_product)){
     			UFDouble ntotalrecetaxmny = vo.getDoubleValue("contract_ntotalrecetaxmny");//����Ŀ+��Ʒ���տ���(��˰)
     			if(codeProductMnyMap.containsKey(vcode)){
     				ntotalrecetaxmny = SafeCompute.add(ntotalrecetaxmny, codeProductMnyMap.get(vcode));
     			}
     			codeProductMnyMap.put(vcode, ntotalrecetaxmny);
     			codeProductSet.add(vcode+pk_product);
     		}
		}
		Map<String,HashVO> projecttypeMap = new HashMap<String,HashVO>();
        for(int i = 0;i<projecttypeList.size();i++){
        	HashVO hashvo = new HashVO();
        	String vcode = (String) projecttypeList.get(i).getAttributeValue("vcode");
        	if(projecttypeList.get(i).getAttributeValue("contract_vcode")==null){//û�к�ͬ��ȡ�����������Ĳ�Ʒ����
        		String pkProjecttype = (String) projecttypeList.get(i).getAttributeValue("projectapprove_projecttype");
        		UFDouble money = new UFDouble((java.math.BigDecimal) projecttypeList.get(i).getAttributeValue("projectapprove_mny"));
        		hashvo.setAttributeValue("pkProjecttype", pkProjecttype);
        		hashvo.setAttributeValue("money", money);
        	}else{
        		String pkProjecttype = (String) projecttypeList.get(i).getAttributeValue("contract_projecttype");
        		UFDouble money = new UFDouble((java.math.BigDecimal) projecttypeList.get(i).getAttributeValue("contract_mny"));
        		String contractVcode = (String) projecttypeList.get(i).getAttributeValue("contract_vcode");
        		UFDate ddealdate = new UFDate((projecttypeList.get(i).getAttributeValue("ddealdate")).toString(),true);
        		//��ͬǩ�����
        		UFDouble contractDealMny = new UFDouble((java.math.BigDecimal) projecttypeList.get(i).getAttributeValue("contract_dealmny"));
        		//ȷ�Ͻ���
        		UFDouble nprocessrate = projecttypeList.get(i).getDoubleValue("nprocessrate");
        		//�Ƿ��տ����
        		String isreceivemnyfinish = (String) projecttypeList.get(i).getAttributeValue("isreceivemnyfinish");
        		hashvo.setAttributeValue("pkProjecttype", pkProjecttype);
        		hashvo.setAttributeValue("money", money);
        		hashvo.setAttributeValue("contractVcode", contractVcode);
        		hashvo.setAttributeValue("ddealdate", ddealdate);
        		hashvo.setAttributeValue("contractdealmny", contractDealMny);
        		hashvo.setAttributeValue("nprocessrate", nprocessrate);
        		hashvo.setAttributeValue("isreceivemnyfinish", isreceivemnyfinish);
        	}
        	hashvo.setAttributeValue("ntotalrecetaxmny", codeProductMnyMap.get(vcode));
         	if(projecttypeMap.containsKey(vcode)){
        		UFDouble oldMoney = (UFDouble) projecttypeMap.get(vcode).getAttributeValue("money");
        		UFDouble newMoney = (UFDouble) hashvo.getAttributeValue("money");
        		if(oldMoney.compareTo(newMoney)<0){
        			projecttypeMap.put(vcode, hashvo);
        		}
        	}else{
        		projecttypeMap.put(vcode, hashvo);
        	}
        }
		return projecttypeMap;
	}
	
    /**
     * ��ȡ��Ҫ����Ŀ״̬����Ŀ��ǰ��̱�
     * @param
     * @return
     */
	public Map<String,HashVO> getImilepostQryMap(Map<String,String> queryMap,String[] pkProjectapprove){
		List<HashVO> imilepostList = new ProjectStatusDetailQryUtil().getImilepostQry(queryMap,pkProjectapprove);
		Map<String,HashVO> imilepostMap = new HashMap<String,HashVO>();
        for(int i = 0;i<imilepostList.size();i++){
        	HashVO hashvo = new HashVO();
        	String vcode = (String) imilepostList.get(i).getAttributeValue("vcode");
        	int iprojecthealthstatus =  (Integer) imilepostList.get(i).getAttributeValue("iprojecthealthstatus");
        	int imilepost = (Integer) imilepostList.get(i).getAttributeValue("imilepost");
        	UFBoolean visfinish = null;
        	if(imilepostList.get(i).getAttributeValue("isfinish")!=null){
        		visfinish = UFBoolean.valueOf(imilepostList.get(i).getAttributeValue("isfinish").toString());	
        	}
        	UFDate dreportenddate = new UFDate((imilepostList.get(i).getAttributeValue("dreportenddate")).toString(),true);
        	if(!YCPubUtils.isEmpty(dreportenddate)){
        		hashvo.setAttributeValue("iprojecthealthstatus", iprojecthealthstatus);
        		hashvo.setAttributeValue("imilepost", imilepost);
        		hashvo.setAttributeValue("visfinish", visfinish);
        		hashvo.setAttributeValue("dreportenddate", dreportenddate);
        		if(imilepostMap.containsKey(vcode)){
        			UFDate oldDreportenddate = (UFDate) imilepostMap.get(vcode).getAttributeValue("dreportenddate");
        			UFDate newDreportenddate = (UFDate) hashvo.getAttributeValue("dreportenddate");
        			if(oldDreportenddate.compareTo(newDreportenddate)<0){
        				imilepostMap.put(vcode, hashvo);
        			}
        		}else{
        			imilepostMap.put(vcode, hashvo);
        		}	
        	}
        }
		return imilepostMap;
	}
	
    /**
     * ��ȡ��Ҫ��ʵ������
     * @param
     * @return
     */
	public Map<String,HashVO> getNumMap(Map<String,String> queryMap,String[] pkProjectapprove){
		List<HashVO> numList = new ProjectStatusDetailQryUtil().getNumQry(queryMap,pkProjectapprove);
		Map<String,HashVO> numMap = new HashMap<String,HashVO>();
        for(int i = 0;i<numList.size();i++){
        	HashVO hashvo = new HashVO();
        	String vcode = (String) numList.get(i).getAttributeValue("vcode");
        	UFDouble rprojectsumnum = null;
        	if(numList.get(i).getAttributeValue("rprojectsumnum")!=null){
        		rprojectsumnum =  new nc.vo.pub.lang.UFDouble((java.math.BigDecimal) numList.get(i).getAttributeValue("rprojectsumnum"));	
        	}
        	UFDouble rsupportnum =null;
        	if(numList.get(i).getAttributeValue("rsupportnum")!=null){
        		rsupportnum = new nc.vo.pub.lang.UFDouble((java.math.BigDecimal) numList.get(i).getAttributeValue("rsupportnum"));
        	}
        	UFDouble nnum = null;
        	if(numList.get(i).getAttributeValue("nnum")!=null){
        		nnum = new nc.vo.pub.lang.UFDouble((java.math.BigDecimal) numList.get(i).getAttributeValue("nnum"));       		
        	}
        	UFDouble ncostmny = null;
        	if(numList.get(i).getAttributeValue("ncostmny")!=null){
        		ncostmny = new nc.vo.pub.lang.UFDouble((java.math.BigDecimal) numList.get(i).getAttributeValue("ncostmny"));
        	}
        	hashvo.setAttributeValue("rprojectsumnum", rprojectsumnum);
        	hashvo.setAttributeValue("rsupportnum", rsupportnum);
        	hashvo.setAttributeValue("nnum", nnum);
        	hashvo.setAttributeValue("ncostmny", ncostmny);
        	numMap.put(vcode, hashvo);
        }
		return numMap;
	}
	
    /**
     * ��ȡ��Ҫ��ʱ��
     * @param
     * @return
     */
	public List<HashVO> getTimeMap(Map<String,String> queryMap,String[] pkProjectapprove){
		List<HashVO> timeList = new ProjectStatusDetailQryUtil().getTimeQry(queryMap,pkProjectapprove);
		List<HashVO> timeRtnList = new ArrayList<HashVO>();
        for(int i = 0;i<timeList.size();i++){
        	HashVO hashvo = new HashVO();
        	UFDate dplanstartdate = null;
        	if(timeList.get(i).getAttributeValue("dplanstartdate")!=null){
        		dplanstartdate = new UFDate(timeList.get(i).getAttributeValue("dplanstartdate").toString(),true);	
        	}
        	UFDate drealstartdate = null;
        	if(timeList.get(i).getAttributeValue("drealstartdate")!=null){
        		drealstartdate = new UFDate(timeList.get(i).getAttributeValue("drealstartdate").toString(),true);	
        	}
        	UFDate dplanfinishdate = null;
        	if(timeList.get(i).getAttributeValue("dplanfinishdate")!=null){
        		dplanfinishdate = new UFDate(timeList.get(i).getAttributeValue("dplanfinishdate").toString(),true);
        	}
        	UFDate dplanenddate = null;
        	if(timeList.get(i).getAttributeValue("dplanenddate")!=null){
        		dplanenddate = new UFDate(timeList.get(i).getAttributeValue("dplanenddate").toString(),true);	
        	}
        	UFDate drealfinishdate = null;
        	if(timeList.get(i).getAttributeValue("drealfinishdate")!=null){
        		drealfinishdate = new UFDate(timeList.get(i).getAttributeValue("drealfinishdate").toString(),true); 		
        	}
        	hashvo.setAttributeValue("vcode", timeList.get(i).getAttributeValue("vcode"));
        	hashvo.setAttributeValue("imilepostdef", timeList.get(i).getAttributeValue("imilepostdef"));
        	hashvo.setAttributeValue("imilepost", timeList.get(i).getAttributeValue("imilepost"));
        	hashvo.setAttributeValue("dplanstartdate", dplanstartdate);
        	hashvo.setAttributeValue("drealstartdate", drealstartdate);
    		if(dplanfinishdate!=null && dplanenddate!=null){
    			if(dplanfinishdate.compareTo(dplanenddate)<0){
    				hashvo.setAttributeValue("dplandate", dplanenddate);
    			}else{
    				hashvo.setAttributeValue("dplandate", dplanfinishdate);
    			}		
    		}else if(dplanfinishdate!=null && dplanenddate==null){
    			hashvo.setAttributeValue("dplandate", dplanfinishdate);
    		}else if(dplanfinishdate==null && dplanenddate!=null){
    			hashvo.setAttributeValue("dplandate", dplanenddate);
    		}else{
    			hashvo.setAttributeValue("dplandate", "");
    		}
    		hashvo.setAttributeValue("drealfinishdate", drealfinishdate);
    		timeRtnList.add(hashvo);
        }
		return timeRtnList;
	}
}
