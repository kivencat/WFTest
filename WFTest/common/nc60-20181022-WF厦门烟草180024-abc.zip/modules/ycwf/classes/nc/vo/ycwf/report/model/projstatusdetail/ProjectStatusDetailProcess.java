package nc.vo.ycwf.report.model.projstatusdetail;

import java.util.List;
import java.util.Map;
import java.util.Set;

import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.lang.UFDouble;
import nc.vo.trade.report.process.IReportDataProcess;
import nc.vo.trade.voutils.SafeCompute;
import nc.vo.yc.utils.YCPubUtils;
import nc.vo.yc.utils.hash.HashVO;
import nc.vo.ycwf.pub.YCWFConstants;

/**
 * ��Ŀ״̬��ϸ��--����Ŀ  ����������sql���ݷ��뱨����
 * @author yanghc
 * @date  2017-06-02
 */
@SuppressWarnings("serial")
public class ProjectStatusDetailProcess implements IReportDataProcess{
	
	private Map<String,String> queryMap = null;
	
	public ProjectStatusDetailProcess(Map<String,String> queryMap) {
		this.queryMap =queryMap;
	}
	 /**
     * ����������
     * @param
     * @return
     */
	public CircularlyAccessibleValueObject[] doProcess(CircularlyAccessibleValueObject[] bodyVOs) {
		if (YCPubUtils.isEmpty(bodyVOs)) {
			return bodyVOs;
		}
		//��ȡ��Ŀpk
		Set<String> pkProjectapproveSet = YCPubUtils.getDistinctFieldValues(bodyVOs, "a_pk_projectapprove", null);
		String[] pkProjectapprove = pkProjectapproveSet.toArray(new String[pkProjectapproveSet.size()]);
		ProjectStatusDetailBusi prjStatusDetBusi = new ProjectStatusDetailBusi();
		Map<String,HashVO> projecttypeMap = prjStatusDetBusi.getProjecttypeMap(queryMap,pkProjectapprove);
		Map<String,HashVO> imilepostMap = prjStatusDetBusi.getImilepostQryMap(queryMap,pkProjectapprove);
		Map<String,HashVO> numMap = prjStatusDetBusi.getNumMap(queryMap,pkProjectapprove);
		List<HashVO> timeList = prjStatusDetBusi.getTimeMap(queryMap,pkProjectapprove);
		for(CircularlyAccessibleValueObject bodyVO: bodyVOs){
			//1.��Ŀ���͡���ͬ�š���ͬǩ������
			setProjecttype(projecttypeMap, bodyVO);
			//2.��Ŀ״̬����Ŀ��ǰ��̱�
			setImilepostMap(imilepostMap, bodyVO);
			//3.ʵ������
			setNumMap(numMap, bodyVO);
			//4.ʱ��
			setTimeList(timeList, bodyVO);
			//5.���ý���ƫ��
			setScheduleVariance(bodyVO);
		}
		return bodyVOs;
	}
	
	 /**
     * ���ý���ƫ��
     * @param
     * @return
     */
	private void setScheduleVariance(CircularlyAccessibleValueObject bodyVO) {
		int plansv = UFDate.getDaysBetween((UFDate)bodyVO.getAttributeValue("plandplanstartdate"), (UFDate) bodyVO.getAttributeValue("plandrealstartdate"));
		int switchsv = UFDate.getDaysBetween((UFDate)bodyVO.getAttributeValue("switchdplanenddate"), (UFDate) bodyVO.getAttributeValue("switchdrealfinishdate"));
		int summarysv = UFDate.getDaysBetween((UFDate)bodyVO.getAttributeValue("summarydplanenddate"), (UFDate) bodyVO.getAttributeValue("summarydrealfinishdate"));
		int supportsv = UFDate.getDaysBetween((UFDate)bodyVO.getAttributeValue("supportdplanenddate"), (UFDate) bodyVO.getAttributeValue("supportdrealfinishdate"));
		bodyVO.setAttributeValue("plansv", plansv);
		bodyVO.setAttributeValue("switchsv", switchsv);
		bodyVO.setAttributeValue("summarysv", summarysv);
		bodyVO.setAttributeValue("supportsv", supportsv);
	}
	
	 /**
     * ��ʱ���ֵ��������
     * @param
     * @return
     */
	private void setTimeList(List<HashVO> timeList, CircularlyAccessibleValueObject bodyVO) {
		for(HashVO hashvo : timeList){
			if(hashvo.getAttributeValue("vcode").equals(bodyVO.getAttributeValue("a_vcode"))){
				//���ʽ
		        if(hashvo.getAttributeValue("imilepostdef").equals(YCWFConstants.IMILEPOST_STAGE_FIVE)){
		        	if(hashvo.getAttributeValue("imilepost").equals(YCWFConstants.IMILEPOST_PLAN_VALUE)){//��Ŀ�滮
		        		bodyVO.setAttributeValue("plandplanstartdate", hashvo.getAttributeValue("dplanstartdate"));
		        		bodyVO.setAttributeValue("plandrealstartdate", hashvo.getAttributeValue("drealstartdate"));
		        	}
		        	if(hashvo.getAttributeValue("imilepost").equals(YCWFConstants.IMILEPOST_SWITCH_VALUE)){//�����л�
		        		bodyVO.setAttributeValue("switchdplanenddate", hashvo.getAttributeValue("dplandate"));
		        		bodyVO.setAttributeValue("switchdrealfinishdate", hashvo.getAttributeValue("drealfinishdate"));
		        	}
		        	if(hashvo.getAttributeValue("imilepost").equals(YCWFConstants.IMILEPOST_SUMMARY_VALUE)){//��Ŀ�ܽ�
		        		bodyVO.setAttributeValue("summarydplanenddate", hashvo.getAttributeValue("dplandate"));
		        		bodyVO.setAttributeValue("summarydrealfinishdate", hashvo.getAttributeValue("drealfinishdate"));
		        	}
		        	if(hashvo.getAttributeValue("imilepost").equals(YCWFConstants.IMILEPOST_SUPPORT_VALUE)){//����֧��
		        		bodyVO.setAttributeValue("supportdplanenddate", hashvo.getAttributeValue("dplandate"));
		        		bodyVO.setAttributeValue("supportdrealfinishdate", hashvo.getAttributeValue("drealfinishdate"));
		        	}
		        }
		        //����ʽ
		        if(hashvo.getAttributeValue("imilepostdef").equals(YCWFConstants.IMILEPOST_STAGE_TWO)){
		        	if(hashvo.getAttributeValue("imilepost").equals(YCWFConstants.IMILEPOST_MAKESURE_VALUE)){//����ȷ��
		        		bodyVO.setAttributeValue("plandplanstartdate", hashvo.getAttributeValue("dplanstartdate"));
		        		bodyVO.setAttributeValue("plandrealstartdate", hashvo.getAttributeValue("drealstartdate"));
		        	}
		        	if(hashvo.getAttributeValue("imilepost").equals(YCWFConstants.IMILEPOST_SUMMARY_VALUE)){//��Ŀ�ܽ�
		        		bodyVO.setAttributeValue("summarydplanenddate", hashvo.getAttributeValue("dplandate"));
		        		bodyVO.setAttributeValue("summarydrealfinishdate", hashvo.getAttributeValue("drealfinishdate"));
		        	}
		        	if(hashvo.getAttributeValue("imilepost").equals(YCWFConstants.IMILEPOST_SUPPORT_VALUE)){//����֧��
		        		bodyVO.setAttributeValue("supportdplanenddate", hashvo.getAttributeValue("dplandate"));
		        		bodyVO.setAttributeValue("supportdrealfinishdate", hashvo.getAttributeValue("drealfinishdate"));
		        	}
		        }
		       //һ��ʽ
		        if(hashvo.getAttributeValue("imilepostdef").equals(YCWFConstants.IMILEPOST_STAGE_ONE)){
		        	if(hashvo.getAttributeValue("imilepost").equals(YCWFConstants.IMILEPOST_SUPPORT_VALUE)){//����֧��
		        		bodyVO.setAttributeValue("plandplanstartdate", hashvo.getAttributeValue("dplanstartdate"));
		        		bodyVO.setAttributeValue("plandrealstartdate", hashvo.getAttributeValue("drealstartdate"));
		        		bodyVO.setAttributeValue("supportdplanenddate", hashvo.getAttributeValue("dplandate"));
		        		bodyVO.setAttributeValue("supportdrealfinishdate", hashvo.getAttributeValue("drealfinishdate"));
		        	}
		        }
		    }
		}
	}
	
	 /**
     * ��ʵ�������ֵ��������
     * @param
     * @return
     */
	private void setNumMap(Map<String, HashVO> numMap, CircularlyAccessibleValueObject bodyVO) {
		for(Map.Entry entry : numMap.entrySet()){
			if(entry.getKey().equals(bodyVO.getAttributeValue("a_vcode"))){
				HashVO hashvo = (HashVO) entry.getValue();
				bodyVO.setAttributeValue("rprojectsumnum", hashvo.getAttributeValue("rprojectsumnum"));
				bodyVO.setAttributeValue("rsupportnum", hashvo.getAttributeValue("rsupportnum"));
				bodyVO.setAttributeValue("nnum", hashvo.getAttributeValue("nnum"));
				bodyVO.setAttributeValue("ncostmny", hashvo.getAttributeValue("ncostmny"));
		    }
		}
	}
	
	 /**
     * ����Ŀ״̬����Ŀ��ǰ��̱���ֵ��������
     * @param
     * @return
     */
	private void setImilepostMap(Map<String, HashVO> imilepostMap, CircularlyAccessibleValueObject bodyVO) {
		for(Map.Entry entry : imilepostMap.entrySet()){
			if(entry.getKey().equals(bodyVO.getAttributeValue("a_vcode"))){
				HashVO hashvo = (HashVO) entry.getValue();
				bodyVO.setAttributeValue("iprojecthealthstatus", hashvo.getAttributeValue("iprojecthealthstatus"));
				if(!YCPubUtils.isEmpty(hashvo.getAttributeValue("visfinish"))){
					if(hashvo.getAttributeValue("visfinish").toString().equals("Y")){
						bodyVO.setAttributeValue("imilepost", "�깤");
					}else{
						bodyVO.setAttributeValue("imilepost", hashvo.getAttributeValue("imilepost"));	
					}
				}
		    }
		}
	}
	
	 /**
     * ����Ŀ���͡���ͬ�š���ͬǩ�����ڵ�ֵ��������
     * @param
     * @return
     */
	private void setProjecttype(Map<String, HashVO> projecttypeMap, CircularlyAccessibleValueObject bodyVO) {
		for(Map.Entry entry : projecttypeMap.entrySet()){
			if(entry.getKey().equals(bodyVO.getAttributeValue("a_vcode"))){
				HashVO hashvo = (HashVO) entry.getValue();
				bodyVO.setAttributeValue("pk_projecttype", hashvo.getAttributeValue("pkProjecttype"));
				if(!YCPubUtils.isEmpty(hashvo.getAttributeValue("contractVcode"))){
					bodyVO.setAttributeValue("vcode", hashvo.getAttributeValue("contractVcode"));
					bodyVO.setAttributeValue("ddealdate", hashvo.getAttributeValue("ddealdate"));
					UFDouble contractdealmny = hashvo.getDoubleValue("contractdealmny");
					UFDouble ntotalrecetaxmny = hashvo.getDoubleValue("ntotalrecetaxmny");
					bodyVO.setAttributeValue("contractdealmny", contractdealmny);//��ͬ���(��˰)
					//δ�տ���(��˰)=��ͬ���(��˰)-�տ���(��˰)
					bodyVO.setAttributeValue("ntotalrecetaxmny", SafeCompute.sub(contractdealmny, ntotalrecetaxmny));
					//ȷ�Ͻ���
					bodyVO.setAttributeValue("nprocessrate", hashvo.getDoubleValue("nprocessrate"));
					//�Ƿ��տ����
					bodyVO.setAttributeValue("isreceivemnyfinish", hashvo.getAttributeValue("isreceivemnyfinish"));
				}
		    }
		}
	}

}
